###################
#  
# CODE by genIThub PVT LTD
#
#
##################

## Installation guide of code

   First, compress whole files and upload it to the server and extract all files into the server after that check of your domain. It works properly and website start running .Thank you for using our service.

## Help
mail at info@genithub.com
www.genithub.com